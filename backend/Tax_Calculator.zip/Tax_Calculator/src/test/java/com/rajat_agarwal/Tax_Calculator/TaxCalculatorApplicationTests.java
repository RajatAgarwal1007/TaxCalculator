package com.rajat_agarwal.Tax_Calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
