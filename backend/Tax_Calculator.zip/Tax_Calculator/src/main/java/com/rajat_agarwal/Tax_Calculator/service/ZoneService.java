package com.rajat_agarwal.Tax_Calculator.service;

import com.rajat_agarwal.Tax_Calculator.Entity.Zone;
import com.rajat_agarwal.Tax_Calculator.Repo.ZoneRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ZoneService {

    private final ZoneRepo zoneRepo;

    @Autowired
    public ZoneService(ZoneRepo zoneRepo) {
        this.zoneRepo = zoneRepo;
    }

    public List<Zone> findAllZone() {
        return zoneRepo.findAll();
    }

}
