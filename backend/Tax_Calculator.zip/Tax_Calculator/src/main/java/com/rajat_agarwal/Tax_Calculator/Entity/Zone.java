package com.rajat_agarwal.Tax_Calculator.Entity;

import javax.persistence.*;

@Entity
public class Zone {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)
    private Long id;
    private String name;
    private Double taxPercentage;


    public Zone() {}

    public Zone(Long id, String name, Double taxPercentage) {
        this.id = id;
        this.name = name;
        this.taxPercentage = taxPercentage;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getTaxPercentage() {
        return taxPercentage;
    }

    public void setTaxPercentage(Double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }

    @Override
    public String toString() {
        return "Zone{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", taxPercentage=" + taxPercentage +
                '}';
    }
}
