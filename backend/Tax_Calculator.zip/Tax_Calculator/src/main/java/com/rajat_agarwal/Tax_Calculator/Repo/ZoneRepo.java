package com.rajat_agarwal.Tax_Calculator.Repo;

import com.rajat_agarwal.Tax_Calculator.Entity.Zone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ZoneRepo extends JpaRepository<Zone, Long> {

}
