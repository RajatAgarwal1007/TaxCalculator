package com.rajat_agarwal.Tax_Calculator.Repo;

import com.rajat_agarwal.Tax_Calculator.Entity.State;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StateRepo extends JpaRepository<State, Long> {
}
