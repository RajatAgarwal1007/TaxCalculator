package com.rajat_agarwal.Tax_Calculator;

import com.rajat_agarwal.Tax_Calculator.Entity.State;
import com.rajat_agarwal.Tax_Calculator.Entity.Tax;
import com.rajat_agarwal.Tax_Calculator.Entity.Zone;

import com.rajat_agarwal.Tax_Calculator.service.StateService;
import com.rajat_agarwal.Tax_Calculator.service.TaxService;
import com.rajat_agarwal.Tax_Calculator.service.ZoneService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TaxController {
    private final ZoneService zoneService;
    private final StateService stateService;
    private final TaxService taxService;

    public TaxController(ZoneService zoneService, StateService stateService, TaxService taxService) {
        this.zoneService = zoneService;
        this.stateService = stateService;
        this.taxService = taxService;
    }

    @GetMapping("/zone")
    public ResponseEntity<List<Zone>> getAllZone() {
        List<Zone> zone = zoneService.findAllZone();
        return new ResponseEntity<>(zone, HttpStatus.OK);
    }

    @GetMapping("/state")
    public ResponseEntity<List<State>> getAllState() {
        List<State> states = stateService.findAllState();
        return new ResponseEntity<>(states, HttpStatus.OK);
    }

    @PostMapping("/tax")
    public ResponseEntity<Tax> addEmployee(@RequestBody Tax tax) {
        Tax w = taxService.addTax(tax);
        return new ResponseEntity<>(w, HttpStatus.CREATED);
    }

    @GetMapping("/calTax/{id}")
    public ResponseEntity<Tax> getCalculatedTax(@PathVariable("id") Long id) {
        Tax w = taxService.findTaxById(id);
        return new ResponseEntity<>(w, HttpStatus.OK);
    }
}
