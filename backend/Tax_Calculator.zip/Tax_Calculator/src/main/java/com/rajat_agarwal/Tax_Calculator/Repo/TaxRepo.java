package com.rajat_agarwal.Tax_Calculator.Repo;

import com.rajat_agarwal.Tax_Calculator.Entity.Tax;
import org.springframework.data.jpa.repository.JpaRepository;

import java.nio.file.OpenOption;
import java.util.Optional;

public interface TaxRepo extends JpaRepository<Tax, Long> {
    Optional<Tax> findTaxById(Long id);
}
