package com.rajat_agarwal.Tax_Calculator.exception;

public class TaxNotFoundException extends RuntimeException{
    public TaxNotFoundException(String message) {
        super(message);
    }
}
