package com.rajat_agarwal.Tax_Calculator.service;

import com.rajat_agarwal.Tax_Calculator.Entity.Tax;
import com.rajat_agarwal.Tax_Calculator.Repo.TaxRepo;
import com.rajat_agarwal.Tax_Calculator.exception.TaxNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;

@Service
@Transactional
public class TaxService {

    private final TaxRepo taxRepo;

    @Autowired
    public TaxService(TaxRepo taxRepo) {
        this.taxRepo = taxRepo;
    }

    public Tax addTax(Tax tax) {
        return taxRepo.save(tax);
    }

    public Tax findTaxById(Long id) {
        return taxRepo.findTaxById(id).orElseThrow(() -> new TaxNotFoundException("Tax by Id "+ id + " was not found"));
    }
}
