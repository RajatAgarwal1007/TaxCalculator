package com.rajat_agarwal.Tax_Calculator.Entity;

import javax.persistence.*;

@Entity
public class Tax {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)
    private Long id;
    private String name;
    private String email;
    private Long amount;
    private Long zoneId;
    private Long stateId;
    private Double calculatedTax;


    public Tax() {}

    public Tax(Long id, String name, String email, Long amount, Long zoneTax, Long stateTax, Double calculatedTax) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.amount = amount;
        this.zoneId = zoneTax;
        this.stateId = stateTax;
        this.calculatedTax = calculatedTax;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getZoneId() {
        return zoneId;
    }

    public void setZoneId(Long zoneId) {
        this.zoneId = zoneId;
    }

    public Long getStateId() {
        return stateId;
    }

    public void setStateId(Long stateId) {
        this.stateId = stateId;
    }

    public Double getCalculatedTax() {
        return calculatedTax;
    }

    public void setCalculatedTax(Double calculatedTax) {
        this.calculatedTax = calculatedTax;
    }

    @Override
    public String toString() {
        return "Tax{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", amount=" + amount +
                ", zoneTax=" + zoneId +
                ", stateTax=" + stateId +
                ", calculatedTax=" + calculatedTax +
                '}';
    }
}
