package com.rajat_agarwal.Tax_Calculator.service;

import com.rajat_agarwal.Tax_Calculator.Entity.State;
import com.rajat_agarwal.Tax_Calculator.Repo.StateRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class StateService {

    private final StateRepo stateRepo;

    @Autowired
    public StateService(StateRepo stateRepo) {
        this.stateRepo = stateRepo;
    }

    public List<State> findAllState() {
        return stateRepo.findAll();
    }
}
